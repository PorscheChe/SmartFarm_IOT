package com.example.smartfarm_iot;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;


public class ManualScreen extends AppCompatActivity {

    TextView potTxt, npk15txt,npk46txt;
    SmartFarmInfo smartFarmInfo = new SmartFarmInfo();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_screen);
        Button backBtn = findViewById(R.id.backBtn1);
        Button pot1OnOf = findViewById(R.id.potOnOff);
        Button npk46Swi = findViewById(R.id.npk46OnOff);
        Button npk15Swi = findViewById(R.id.npk15OnOff3);
        npk15txt = findViewById(R.id.npk15_man_text);
        npk15txt.setText(Boolean.toString(smartFarmInfo.isNpk15()));
        npk46txt = findViewById(R.id.npk46_man_text);
        npk46txt.setText(Boolean.toString(smartFarmInfo.isNpk46()));
        potTxt = findViewById(R.id.pot1_Txt);
        potTxt.setText(Boolean.toString(smartFarmInfo.isPot1()));

        //Event Listener
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        pot1OnOf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(potTxt.getText().equals("false")){
                    potTxt.setText("true");
                    smartFarmInfo.setPot1(true);
                }else if(potTxt.getText().equals("true"))
                {
                    potTxt.setText("false");
                    smartFarmInfo.setPot1(false);
                }
            }
        });
        npk15Swi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(npk15txt.getText().equals("false")){
                    npk15txt.setText("true");
                    smartFarmInfo.setNpk15(true);
                }else if(npk15txt.getText().equals("true"))
                {
                    npk15txt.setText("false");
                    smartFarmInfo.setNpk15(false);
                }
            }
        });
        npk46Swi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(npk46txt.getText().equals("false")){
                    npk46txt.setText("true");
                    smartFarmInfo.setNpk46(true);
                }else if(npk46txt.getText().equals("true"))
                {
                    npk46txt.setText("false");
                    smartFarmInfo.setNpk46(false);
                }
            }
        });
    }
}