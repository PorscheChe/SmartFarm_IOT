package com.example.smartfarm_iot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button config, monitor, setTime, manual, load, onOff;
    Intent ConfigPage, ManualScreen, MonitorPage, sTime;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    SmartFarmInfo smartFarmInfo = new SmartFarmInfo();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //findViewById

        config = findViewById(R.id.config_Btn);
        monitor = findViewById(R.id.monitor_Btn);
        setTime = findViewById(R.id.setTime_Btn);
        manual = findViewById(R.id.manual_Btn);
        load = findViewById(R.id.loadBtn);
        onOff = findViewById(R.id.onOffBtn);
        TextView onOff_txt = findViewById(R.id.onoff_Text);
        String isAut = Boolean.toString(smartFarmInfo.isAuto());
        onOff_txt.setText(isAut);

        //onClick
        config.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConfigPage = new Intent(getApplicationContext(), ConfigPage.class);
                startActivity(ConfigPage);
            }
        });
        monitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MonitorPage = new Intent(getApplicationContext(), com.example.smartfarm_iot.monitor.class);
                startActivity(MonitorPage);
            }
        });
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ManualScreen = new Intent(getApplicationContext(), com.example.smartfarm_iot.ManualScreen.class);
                startActivity(ManualScreen);
            }
        });
        setTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sTime = new Intent(getApplicationContext(),SetTime.class);
                startActivity(sTime);
            }
        });
        onOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(onOff_txt.getText().equals("false")){
                    onOff_txt.setText("true");
                    smartFarmInfo.setAuto(true);
                }else if(onOff_txt.getText().equals("true"))
                {
                    onOff_txt.setText("false");
                    smartFarmInfo.setAuto(false);
                }
            }
        });
    }
}