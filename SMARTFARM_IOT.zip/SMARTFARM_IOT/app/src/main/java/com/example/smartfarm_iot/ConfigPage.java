package com.example.smartfarm_iot;

import android.os.Bundle;
import android.provider.Telephony;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ConfigPage extends AppCompatActivity {
    Spinner spinner;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Button okConf, savebtn;
    TextView moistTxt,npk46Txt,npk14Txt;
    int hour,minute;
    int npk15,npk46;
    float moisture;
    SmartFarmInfo smartFarmInfo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        moistTxt = findViewById(R.id.moist_TxtField);
        npk14Txt = findViewById(R.id.npk15_txtField2);
        npk46Txt = findViewById(R.id.npk46_txtField);
        //FindViewById
        spinner = findViewById(R.id.daySpinner);
        Button backBtn = findViewById(R.id.back_config_btn);
        okConf = findViewById(R.id.okConfig);
        savebtn = findViewById(R.id.load_config_btn);
        //ArrayAdapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.days,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spinner.setAdapter(adapter);

        //EventListener
        okConf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadData();
            }
        });
        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeData(spinner.getSelectedItem().toString(),Float.parseFloat(moistTxt.getText().toString()), Integer.parseInt(npk14Txt.getText().toString()), Integer.parseInt(npk46Txt.getText().toString()));
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        return true;
    }

    private void loadData(){
        moistTxt = findViewById(R.id.moist_TxtField);
        npk14Txt = findViewById(R.id.npk15_txtField2);
        npk46Txt = findViewById(R.id.npk46_txtField);
        String ref = spinner.getSelectedItem().toString();
        firebaseDatabase = FirebaseDatabase.getInstance(
                "https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/"
        );
        databaseReference = firebaseDatabase.getReference(ref);
        databaseReference.child("NPK15").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                npk15 = snapshot.getValue(Integer.class);
                npk14Txt.setText(Integer.toString(npk15));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        databaseReference.child("NPK46").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                npk46 = snapshot.getValue(Integer.class);
                npk46Txt.setText(Integer.toString(npk46));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        databaseReference.child("Moisture").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                moisture = snapshot.getValue(Float.class);
                Toast.makeText(ConfigPage.this, Float.toString(moisture), Toast.LENGTH_SHORT).show();
                moistTxt.setText(Float.toString(moisture));
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



    private void writeData(String day, float moisture, int npk15, int npk46){
        firebaseDatabase = firebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference(day);

        Map<String,Object> update = new HashMap<String ,Object>();

        update.put("Moisture",moisture);
        update.put("NPK15", npk15);
        update.put("NPK46", npk46);
        databaseReference.updateChildren(update);
    }
}