package com.example.smartfarm_iot;

public class ManualController {
    private Boolean pot1Bool;
    private Boolean npk15Bool;
    private Boolean npk46Bool;

    public ManualController() { }

    public ManualController(Boolean pot1Bool,Boolean npk15Bool, Boolean npk46Bool){
        this.npk15Bool = npk15Bool;
        this.npk46Bool = npk46Bool;
        this.pot1Bool = pot1Bool;
    }

    public Boolean getNpk15Bool() {
        return npk15Bool;
    }

    public Boolean getNpk46Bool() {
        return npk46Bool;
    }

    public Boolean getPot1Bool() {
        return pot1Bool;
    }

    public void setNpk15Bool(Boolean npk15Bool) {
        this.npk15Bool = npk15Bool;
    }

    public void setNpk46Bool(Boolean npk46Bool) {
        this.npk46Bool = npk46Bool;
    }

    public void setPot1Bool(Boolean pot1Bool) {
        this.pot1Bool = pot1Bool;
    }
}
