package com.example.smartfarm_iot;

import android.provider.ContactsContract;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Time;
import java.util.HashMap;
import java.util.Map;

public class TimeController {

    int hour, min;
    String day;
    FirebaseDatabase firebaseDatabase =firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");;
    DatabaseReference databaseReference;
    public  TimeController(){}

    public int getHour(String day) {
        databaseReference = firebaseDatabase.getReference(day);
        databaseReference.child("Hour").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                hour = snapshot.getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return hour;
    }

    public int getMin(String day) {
        databaseReference = firebaseDatabase.getReference(day);
        databaseReference.child("Min").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                min = snapshot.getValue(Integer.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return min;
    }

   public void writeData(String day, int hour, int min){
       databaseReference = firebaseDatabase.getReference(day);
       Map<String,Object> update = new HashMap<String ,Object>();
       update.put("Hour", hour);
       update.put("Min", min);
       databaseReference.updateChildren(update);
   }
}
