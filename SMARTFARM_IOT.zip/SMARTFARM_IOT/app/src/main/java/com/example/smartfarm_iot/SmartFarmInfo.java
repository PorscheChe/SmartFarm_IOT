package com.example.smartfarm_iot;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.Duration;

public class SmartFarmInfo {
    private String humidity;
    private boolean npk15;
    private boolean npk46;
    private boolean pot1;

    public boolean isPot1() {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("pot1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pot1 = snapshot.getValue(Boolean.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return pot1;
    }

    public void setPot1(boolean pot1) {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("pot1").setValue(pot1);
    }

    private boolean auto;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    public SmartFarmInfo(){}

    public boolean isAuto() {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("auto");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                auto = snapshot.getValue(Boolean.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
        return auto;
    }

    public void setAuto(boolean auto) {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("auto");
        databaseReference.setValue(auto);
    }

    public String getHumidity() {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("Day1");

        databaseReference.child("Moisture").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                humidity = snapshot.getValue().toString();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public boolean isNpk15() {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("npk15").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                npk15 = snapshot.getValue(Boolean.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        return npk15;
    }

    public void setNpk15(boolean npk15) {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("npk15").setValue(npk15);
    }

    public boolean isNpk46() {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("npk46").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                npk46 = snapshot.getValue(Boolean.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        return npk46;
    }

    public void setNpk46(boolean npk46) {
        firebaseDatabase = FirebaseDatabase.getInstance("https://smart-farm-iot-7a9f1-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = firebaseDatabase.getReference("manual");
        databaseReference.child("npk46").setValue(npk46);
    }
}
