package com.example.smartfarm_iot;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Time;

public class SetTime extends AppCompatActivity {
    TimeController tc = new TimeController();
    Button load ,save ,back;
    TextView hourInp, minInp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_time);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        Spinner spinner = findViewById(R.id.timeSpinner);
        load = findViewById(R.id.loadTIme);
        save = findViewById(R.id.saveTimeBtn);
        back = findViewById(R.id.BackTimeBtn);
        hourInp = findViewById(R.id.inpHour);
        minInp = findViewById(R.id.minInp);

        //ArrayAdapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.days,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spinner.setAdapter(adapter);


        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hourInp.setText(String.valueOf(tc.getHour(spinner.getSelectedItem().toString())));
                minInp.setText(String.valueOf(tc.getMin(spinner.getSelectedItem().toString())));
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tc.writeData(spinner.getSelectedItem().toString(),Integer.parseInt(hourInp.getText().toString()),Integer.parseInt(minInp.getText().toString()));
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        return true;
    }

}